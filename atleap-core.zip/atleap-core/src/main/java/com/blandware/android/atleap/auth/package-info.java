/**
 * This package contains classes which can help with authentication using {@link android.accounts.AccountManager}.
 */
package com.blandware.android.atleap.auth;